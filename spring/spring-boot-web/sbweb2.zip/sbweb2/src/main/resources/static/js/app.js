
$(document).ready(function(){
    $("#status").text("Page is loaded.." + new Date());
});
